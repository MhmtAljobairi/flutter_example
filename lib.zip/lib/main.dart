import 'package:buttonsexamples/calculator_page.dart';
import 'package:buttonsexamples/home_page.dart';
import 'package:buttonsexamples/instgram.dart';
import 'package:buttonsexamples/state_page.dart';
import 'package:buttonsexamples/tiktok.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "My Buttons Example",
      theme: ThemeData(primarySwatch: Colors.blue),
      home: TiktokPage(),
    );
  }
}
